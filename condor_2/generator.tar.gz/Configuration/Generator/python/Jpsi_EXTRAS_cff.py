
from Configuration.Generator.JpsiMM_cfi import *
from Configuration.Generator.JpsiMM_filt_cfi import *

ProductionFilterSequence = cms.Sequence(mumugenfilter)
